public class Staff extends DBEntity{
    //properties
    private String id;
    private String name;
    private String gender;
    private String department;
    private String designation;

    //setter method

    public void set(String id, String name, String gender, String department, String designation){
        this.id=id;
        this.name=name;
        this.gender=gender;
        this.department=department;
        this.designation=designation;
    }

    //separate setter method
    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
//    @Override
//    public void insert(DBEntity e){
//        System.out.println("from insert method of Staff class");
//    }
//
//    @Override
//    public void delete(int i){
//        System.out.println("from delete method of Staff class");
//    }
//
//    @Override
//    public void update(int i, DBEntity d){
//        System.out.println("from update method of Staff class");
//    }

    @Override
    public void insert(DBEntity e) {
        Staff s = (Staff) e;
        System.out.println("Inserting staff with id: " + s.id + " into database");
    }

    @Override
    public void delete(int i) {
        System.out.println("Deleting staff with id: " + i + " from database");
    }

    @Override
    public void update(int i, DBEntity e) {
        Staff s = (Staff) e;
        System.out.println("Modifying information of staff with id: " + i + " in database");
    }
}
