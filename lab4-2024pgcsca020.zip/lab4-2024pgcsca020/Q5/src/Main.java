// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //Doctor
        Doctor d = (Doctor)DBEntity.getEntity("doctor");
        d.setId("1");
        d.setName("A");
        d.setSpec("Neuro");
        d.insert(d);

        //Staff
        Staff s = (Staff)DBEntity.getEntity("staff");
        s.setId("2");
        s.setName("B");
        s.setGender("Male");
        s.setDepartment("Administration");
        s.setDesignation("Manager");
        s.insert(s);

        //Patient
        Patient p = (Patient)DBEntity.getEntity("patient");
        p.setId("3");
        p.setName("C");
        p.setGender("Female");
        p.setAge(25);
        p.insert(p);

        //invoking alter method
        d.alter();
        s.alter();
        p.alter();
    }
}