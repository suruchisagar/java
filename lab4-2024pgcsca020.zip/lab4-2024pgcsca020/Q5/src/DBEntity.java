public abstract class DBEntity {

    //changes from interfaces
    abstract void insert(DBEntity e);
    abstract void delete(int i);
    abstract void update(int i, DBEntity d);

        //static factory method
        static DBEntity getEntity(String type) {
            switch (type.toLowerCase()) {
                case "doctor":
                    return new Doctor();
                case "staff":
                    return new Staff();
                case "patient":
                    return new Patient();
                default:
                    return null;
            }
        }

        //method in interface that no need to be implemented by the classes so declare it default

    void alter() {
            System.out.println("alter method in DBEntity");
        }
}
