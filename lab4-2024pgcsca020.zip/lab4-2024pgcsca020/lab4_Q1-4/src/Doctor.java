public class Doctor implements DBEntity {

    //adding some properties
    private String id;
    private String name;
    private String specialization;
    private String chamber_floor;

    //setter method
    public void set(String id, String name, String specialization, String chamber_floor){
        this.id=id;
        this.name=name;
        this.specialization=specialization;
        this.chamber_floor=chamber_floor;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpec(String specialization) {
        this.specialization = specialization;
    }

    public void setChamberFloor(String chamber_floor) {
        this.chamber_floor = chamber_floor;
    }

//    @Override
//    public void insert(DBEntity e){
//        System.out.println("from insert method of Doctor class");
//    }
//
//
//    @Override
//    public void delete(int i){
//        System.out.println("from delete method of Doctor class");
//    }
//
//    @Override
//    public void update(int i, DBEntity d){
//        System.out.println("from update method of Doctor class");
//    }
    @Override
    public void insert(DBEntity e) {
        Doctor d = (Doctor) e;
        System.out.println("Inserting doctor with id: " + d.id + " into database");
    }

    @Override
    public void delete(int i) {
        System.out.println("Deleting doctor with id: " + i + " from database");
    }

    @Override
    public void update(int i, DBEntity e) {
        Doctor d = (Doctor) e;
        System.out.println("Modifying information of doctor with id: " + i + " in database");
    }
}
