public interface DBEntity {
    void insert(DBEntity e);
    void delete(int i);
    void update(int i, DBEntity d);

    //static factory method
    static DBEntity getEntity(String type) {
        switch (type.toLowerCase()) {
            case "doctor":
                return new Doctor();
            case "staff":
                return new Staff();
            case "patient":
                return new Patient();
            default:
                return null;
        }
    }

    //method in interface that no need to be implemented by the classes so declare it default
    default void alter() {
        System.out.println("Default alter method in DBEntity");
    }
}
