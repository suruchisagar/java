public class Patient implements DBEntity {

    //properties
    private String id;
    private String name;
    private int age;
    private String gender;

    //setter method
    public void set(String id, String name, String gender, int age){
        this.id=id;
        this.name=name;
        this.gender=gender;
        this.age=age;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

//    @Override
//    public void insert(DBEntity e){
//        System.out.println("from insert method of Patient class");
//    }
//
//    @Override
//    public void delete(int i){
//        System.out.println("from delete method of Patient class");
//    }
//
//    @Override
//    public void update(int i, DBEntity d){
//        System.out.println("from update method of Patient class");
//    }

    @Override
    public void insert(DBEntity e) {
        Patient p = (Patient) e;
        System.out.println("Inserting patient with id: " + p.id + " into database");
    }

    @Override
    public void delete(int i) {
        System.out.println("Deleting patient with id: " + i + " from database");
    }

    @Override
    public void update(int i, DBEntity e) {
        Patient p = (Patient) e;
        System.out.println("Modifying information of patient with id: " + i + " in database");
    }
}
